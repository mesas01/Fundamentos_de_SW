package com.javeriana.bancosoft.services;

public class CuentaService {
    
}
