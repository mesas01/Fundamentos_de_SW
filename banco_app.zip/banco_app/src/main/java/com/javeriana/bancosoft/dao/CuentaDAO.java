package com.javeriana.bancosoft.dao;

public class CuentaDAO {
    
}
