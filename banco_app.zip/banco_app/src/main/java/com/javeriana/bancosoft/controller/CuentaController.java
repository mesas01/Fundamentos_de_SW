package com.javeriana.bancosoft.controller;

public class CuentaController {
    
}
