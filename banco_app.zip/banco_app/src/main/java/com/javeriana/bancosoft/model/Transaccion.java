package com.javeriana.bancosoft.model;

public class Transaccion {
    
}
