package com.javeriana.bancosoft.model;

public class Cuenta {
    
}
