package main.java.com.javeriana.model.enmus;

public class TipoCuenta {
    
}
